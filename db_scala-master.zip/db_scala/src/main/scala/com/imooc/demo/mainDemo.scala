package com.imooc.demo

/**
 * Created by xuwei
 */
object mainDemo {
  /**
   * 注意：main方法只能定义在object中，不能定义在class中
   * @param args
   */
  def main(args: Array[String]): Unit = {
    println("hello scala!")
  }

}
